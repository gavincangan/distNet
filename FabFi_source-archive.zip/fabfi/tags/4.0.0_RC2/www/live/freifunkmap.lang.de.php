<?php

define( "TEXT_SEARCH", "Suche");
define( "TEXT_SEARCH_BUTTON_DESCRIPTION", "Freifunkknoten suchen");
define( "TEXT_SHOW_BATMAN_DESCRIPTION", "Zeige batman Knoten");
define( "TEXT_SHOW_OLSR_DESCRIPTION", "Zeige olsr Knoten");
define( "TEXT_SHOW_CONN_DESCRIPTION", "Zeige Verbindungen");
define( "TEXT_SHOW_LQ_DESCRIPTION", "Zeige Link Qualitäten");
define( "TEXT_STATISTICS", "Statistiken");
define( "TEXT_FAQ_DESCRIPTION", "Häufig gestellte Fragen");
define( "TEXT_MEASSURE_DISTANCE", "Entfernung messen");
define( "TEXT_SEARCH_RESULT", "Suchergebnis");
define( "TEXT_ANTENNA_TYPE", "Antennentyp");
define( "TEXT_ANTENNA_GAIN", "Antennengewinn");
define( "TEXT_ANTENNA_BEAM_W", "Öffnungswinkel (Pol.-Ebene)");
define( "TEXT_ANTENNA_BEAM_O", "Öffnungswinkel (gegen Pol.Ebene)");
define( "TEXT_ANTENNA_HEIGHT", "Höhe");
define( "TEXT_ANTENNA_DIRECTION", "Richtung");
define( "TEXT_ANTENNA_TILT", "Neigung");
define( "TEXT_ANTENNA_POLARIZATION", "Polarisation");
define( "TEXT_DISTANCE", "Entfernung");

?>
