<?php

define( "TEXT_SEARCH", "Search");
define( "TEXT_SEARCH_BUTTON_DESCRIPTION", "search for nodes");
define( "TEXT_SHOW_BATMAN_DESCRIPTION", "show batman nodes");
define( "TEXT_SHOW_OLSR_DESCRIPTION", "show olsr nodes");
define( "TEXT_SHOW_CONN_DESCRIPTION", "show connections");
define( "TEXT_SHOW_LQ_DESCRIPTION", "show link qualities");
define( "TEXT_STATISTICS", "statistics");
define( "TEXT_FAQ_DESCRIPTION", "frequently asked questions");
define( "TEXT_MEASSURE_DISTANCE", "meassure distance");
define( "TEXT_SEARCH_RESULT", "Search result");
define( "TEXT_ANTENNA_TYPE", "Antenna typ");
define( "TEXT_ANTENNA_GAIN", "Antenna gain");
define( "TEXT_ANTENNA_BEAM_W", "Beam width (with polarization)");
define( "TEXT_ANTENNA_BEAM_O", "Beam width (perpendicular to polarization)");
define( "TEXT_ANTENNA_HEIGHT", "Height");
define( "TEXT_ANTENNA_DIRECTION", "Direction");
define( "TEXT_ANTENNA_TILT", "Tilt");
define( "TEXT_ANTENNA_POLARIZATION", "Polarization");
define( "TEXT_DISTANCE", "Distance");

?>
